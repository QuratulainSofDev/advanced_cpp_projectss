

#ifndef UNTITLED9_ARRAY_H
#define UNTITLED9_ARRAY_H
#include <iostream>
#include <cassert>

class Array {
private:
    int* Data;
    int Size;

public:
    Array(); // Default constructor
    Array(int size); // Parametrized constructor
    Array(int* arr, int size); // Constructor with an existing array
    Array(const Array& other); // Copy constructor
    ~Array(); // Destructor

    // Operator overloads
    int& operator[](int i);
    const int& operator[](int i) const;
    const Array& operator=(const Array& other);
    Array operator+(const Array& other);
    Array operator-(const Array& other);
    Array operator++(); // Pre-increment
    Array operator++(int); // Post-increment
    Array& operator--(); // Pre-decrement
    bool operator==(const Array& other) const;
    bool operator!() const;
    void operator+=(const Array& other);
    void operator-=(const Array& other);
    int operator()(int idx, int val);
};
//   Implementation opretor

Array::Array() : Data(nullptr), Size(0) {
    // Default constructor
}

Array::Array(int _Size) : Size(_Size) {
    Data = new int[Size];
    for (int i = 0; i < Size; ++i) {
        Data[i] = 0;
    }
}

Array::Array(int* arr, int _Size) : Size(_Size) {
    Data = new int[Size];
    for (int i = 0; i < Size; ++i) {
        Data[i] = arr[i];
    }
}

Array::Array(const Array& other) : Size(other.Size) {
    Data = new int[Size];
    for (int i = 0; i < Size; ++i) {
        Data[i] = other.Data[i];
    }
}

Array::~Array() {
    delete[] Data;
}

int& Array::operator[](int i) {
    assert(i >= 0 && i < Size);
    return Data[i];
}

const int& Array::operator[](int i) const {
    assert(i >= 0 && i < Size);
    return Data[i];
}
const Array& Array::operator=(const Array& other) {
    if (this == &other) {
        return *this;
    }
    delete[] Data;
    Size = other.Size;
    Data = new int[Size];
    for (int i = 0; i < Size; ++i) {
        Data[i] = other.Data[i];
    }
    return *this;
}
Array Array::operator+(const Array& other) {
    assert(Size == other.Size);
    Array result(Size);
    for (int i = 0; i < Size; ++i) {
        result.Data[i] = Data[i] + other.Data[i];
    }
    return result;
}
Array Array::operator-(const Array& other) {
    assert(Size == other.Size);
    Array result(Size);
    for (int i = 0; i < Size; ++i) {
        result.Data[i] = Data[i] - other.Data[i];
    }
    return result;
}

Array Array::operator++() {
    for (int i = 0; i < Size; ++i) {
        ++Data[i];
    }
    return *this;
}

Array Array::operator++(int) {
    Array temp(*this);
    ++(*this);
    return temp;
}

Array& Array::operator--() {
    for (int i = 0; i < Size; ++i) {
        --Data[i];
    }
    return *this;
}

bool Array::operator==(const Array& other) const {
    if (Size != other.Size) {
        return false;
    }
    for (int i = 0; i < Size; ++i) {
        if (Data[i] != other.Data[i]) {
            return false;
        }
    }
    return true;
}

bool Array::operator!() const {
    return Size == 0;
}

void Array::operator+=(const Array& other) {
    assert(Size == other.Size);
    for (int i = 0; i < Size; ++i) {
        Data[i] += other.Data[i];
    }
}

void Array::operator-=(const Array& other) {
    assert(Size == other.Size);
    for (int i = 0; i < Size; ++i) {
        Data[i] -= other.Data[i];
    }
}
int Array::operator()(int idx, int val) {
    if (idx >= 0 && idx < Size) {
        for (int i = idx; i < Size - 1; ++i) {
            Data[i] = Data[i + 1];
        }
        Data[Size - 1] = val;
        --Size;
        return 1; // Successful deletion
    }
    return -1; // Invalid index
}



#endif //UNTITLED9_ARRAY_H
