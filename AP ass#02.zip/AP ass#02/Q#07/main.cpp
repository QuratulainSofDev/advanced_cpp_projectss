#include <iostream>
#include "Array.h"

int main() {
    // Example usage of the Array class with the defined operators
    Array a1(6);
    Array a2(6);
    Array result;

    a1[0] = 1;
    a1[1] = 2;
    a1[2] = 3;

    a2[0] = 4;
    a2[1] = 5;
    a2[2] = 6;

    result = a1 + a2;
    // result now contains {5, 7, 9, 0, 0}

    return 0;
}