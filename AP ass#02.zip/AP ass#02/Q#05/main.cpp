#include <iostream>
#include "Matrix.h"
#include "Matrix.cpp"

using namespace std;

int main() {
    // Create a 2x2 matrix
    Matrix matrix2x2(1, 2, 3, 4);

    // Create a 3x3 matrix
    Matrix matrix3x3(1, 2, 3, 4, 5, 6, 7, 8, 9);

    // Create a 4x4 matrix
    Matrix matrix4x4(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16);

    // Access matrix elements and perform operations
    cout << "2x2 Matrix Total: " << matrix2x2.Total() << endl;
    cout << "3x3 Matrix Average: " << matrix3x3.Average() << endl;
    cout << "4x4 Matrix Row Total (Row 1): " << matrix4x4.RowTotal(1) << endl;
    cout << "4x4 Matrix Column Total (Column 2): " << matrix4x4.ColumnTotal(2) << endl;
    cout << "4x4 Matrix Highest Value in Row 2: " << matrix4x4.HighestInRow(2) << endl;
    cout << "4x4 Matrix Lowest Value in Row 3: " << matrix4x4.LowestInRow(3) << endl;

    // Transpose the 3x3 matrix
    Matrix transposedMatrix3x3 = matrix3x3.Transpose();
    cout << "3x3 Matrix Transpose:" << endl;
    for (int i = 0; i < transposedMatrix3x3.getRow(); ++i) {
        for (int j = 0; j < transposedMatrix3x3.getCol(); ++j) {
            cout << transposedMatrix3x3.getValue(i, j) << " ";
        }
        cout << endl;
    }

    // Matrix addition example
    Matrix addResult = matrix2x2.Add(matrix2x2);
    cout << "Matrix Addition Result (2x2):" << endl;
    for (int i = 0; i < addResult.getRow(); ++i) {
        for (int j = 0; j < addResult.getCol(); ++j) {
            cout << addResult.getValue(i, j) << " ";
        }
        cout << endl;
    }

    // Find the 2nd smallest and 3rd largest elements in the 4x4 matrix
    int kSmallest = matrix4x4.FindkSmallest(2);
    int kLargest = matrix4x4.FindkLargest(3);
    cout << "2nd Smallest in 4x4 Matrix: " << kSmallest << endl;
    cout << "3rd Largest in 4x4 Matrix: " << kLargest << endl;

    return 0;
}
