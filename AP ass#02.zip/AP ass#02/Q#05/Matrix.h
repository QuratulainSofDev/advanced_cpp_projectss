

#ifndef UNTITLED5_MATRIX_H
#define UNTITLED5_MATRIX_H

class Matrix {
private:
    int** matrix; // 2D array
    int row; // Number of rows
    int col; // Number of columns i

public:
    Matrix(int n1, int n2, int n3, int n4, int row = 2, int col = 2); // Parametrized constructor for a 2x2 matrix
    Matrix(int n1, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int row = 3, int col = 3); // Parametrized constructor for a 3x3 matrix
    Matrix(int n1, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10, int n11, int n12, int n13, int n14, int n15, int n16, int row = 4, int col = 4); // Parametrized constructor for a 4x4 matrix
    Matrix(const Matrix &m); // Copy constructor
    ~Matrix(); // Destructor

    int getRow() const; // Getter for rows
    int getCol() const; // Getter for columns
    int getValue(int row, int col) const; // Get the value at the given row and column of the matrix
    void setValue(int row, int col, int value); // Set the value at a given row and column index of the matrix

    int Total() const; // Calculate the total/sum of all the values in the matrix
    double Average() const; // Calculate the average of all the values in the matrix
    int RowTotal(int row) const; // Calculate total/sum of the values in the specified row
    int ColumnTotal(int col) const; // Calculate total/sum of the values in the specified column
    int HighestInRow(int row) const; // Find the highest value in the specified row of the matrix
    int LowestInRow(int row) const; // Find the lowest value in the specified row of the matrix
    Matrix Transpose() const; // Find the Transpose of the matrix
    int LeftDiagonalTotal() const; // Calculate total/sum of the values in the left Diagonal of the matrix
    int RightDiagonalTotal() const; // Calculate total/sum of the values in the right Diagonal of the matrix
    Matrix Add(const Matrix& m) const; // Add the calling object matrix with the one passed as an argument and return a resultant matrix
    Matrix Subtract(const Matrix& m) const; // Subtract the calling object matrix with the one passed as an argument and return a resultant matrix
    Matrix Multiply(const Matrix& m) const; // Multiply the calling object matrix with the one passed as an argument and return a resultant matrix
    int FindkSmallest(int k) const; // Find the kth smallest element in the matrix
    int FindkLargest(int k) const; // Find the kth largest element in the matrix
};

#endif //UNTITLED5_MATRIX_H
