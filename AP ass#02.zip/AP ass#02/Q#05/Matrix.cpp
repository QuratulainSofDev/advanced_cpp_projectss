#include "Matrix.h"

Matrix::Matrix(int n1, int n2, int n3, int n4, int row, int col) {
    this->row = row;
    this->col = col;
    matrix = new int*[row];
    for (int i = 0; i < row; ++i) {
        matrix[i] = new int[col];
    }
    matrix[0][0] = n1;
    matrix[0][1] = n2;
    matrix[1][0] = n3;
    matrix[1][1] = n4;
}

Matrix::Matrix(int n1, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int row, int col) {
    this->row = row;
    this->col = col;
    matrix = new int*[row];
    for (int i = 0; i < row; ++i) {
        matrix[i] = new int[col];
    }
    matrix[0][0] = n1;
    matrix[0][1] = n2;
    matrix[0][2] = n3;
    matrix[1][0] = n4;
    matrix[1][1] = n5;
    matrix[1][2] = n6;
    matrix[2][0] = n7;
    matrix[2][1] = n8;
    matrix[2][2] = n9;
}

Matrix::Matrix(int n1, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10, int n11, int n12, int n13, int n14, int n15, int n16, int row, int col) {
    this->row = row;
    this->col = col;
    matrix = new int*[row];
    for (int i = 0; i < row; ++i) {
        matrix[i] = new int[col];
    }
    matrix[0][0] = n1;
    matrix[0][1] = n2;
    matrix[0][2] = n3;
    matrix[0][3] = n4;
    matrix[1][0] = n5;
    matrix[1][1] = n6;
    matrix[1][2] = n7;
    matrix[1][3] = n8;
    matrix[2][0] = n9;
    matrix[2][1] = n10;
    matrix[2][2] = n11;
    matrix[2][3] = n12;
    matrix[3][0] = n13;
    matrix[3][1] = n14;
    matrix[3][2] = n15;
    matrix[3][3] = n16;
}

Matrix::Matrix(const Matrix &m) {
    this->row = m.row;
    this->col = m.col;
    matrix = new int*[row];
    for (int i = 0; i < row; ++i) {
        matrix[i] = new int[col];
        for (int j = 0; j < col; ++j) {
            matrix[i][j] = m.matrix[i][j];
        }
    }
}

Matrix::~Matrix() {
    for (int i = 0; i < row; ++i) {
        delete[] matrix[i];
    }
    delete[] matrix;
}

int Matrix::getRow() const {
    return row;
}

int Matrix::getCol() const {
    return col;
}

int Matrix::getValue(int row, int col) const {
    return matrix[row][col];
}

void Matrix::setValue(int row, int col, int value) {
    matrix[row][col] = value;
}

int Matrix::Total() const {
    int sum = 0;
    for (int i = 0; i < row; ++i) {
        for (int j = 0; j < col; ++j) {
            sum += matrix[i][j];
        }
    }
    return sum;
}

double Matrix::Average() const {
    return static_cast<double>(Total()) / (row * col);
}

int Matrix::RowTotal(int row) const {
    int sum = 0;
    for (int i = 0; i < col; ++i) {
        sum += matrix[row][i];
    }
    return sum;
}

int Matrix::ColumnTotal(int col) const {
    int sum = 0;
    for (int i = 0; i < row; ++i) {
        sum += matrix[i][col];
    }
    return sum;
}

int Matrix::HighestInRow(int row) const {
    int maxVal = matrix[row][0];
    for (int i = 1; i < col; ++i) {
        if (matrix[row][i] > maxVal) {
            maxVal = matrix[row][i];
        }
    }
    return maxVal;
}

int Matrix::LowestInRow(int row) const {
    int minVal = matrix[row][0];
    for (int i = 1; i < col; ++i) {
        if (matrix[row][i] < minVal) {
            minVal = matrix[row][i];
        }
    }
    return minVal;
}

Matrix Matrix::Transpose() const {
    Matrix transposedMatrix(*this);
    for (int i = 0; i < row; ++i) {
        for (int j = 0; j < col; ++j) {
            transposedMatrix.matrix[i][j] = matrix[j][i];
        }
    }
    return transposedMatrix;
}

int Matrix::LeftDiagonalTotal() const {
    int sum = 0;
    for (int i = 0; i < row && i < col; ++i) {
        sum += matrix[i][i];
    }
    return sum;
}

int Matrix::RightDiagonalTotal() const {
    int sum = 0;
    for (int i = 0; i < row && i < col; ++i) {
        sum += matrix[i][col - i - 1];
    }
    return sum;
}

Matrix Matrix::Add(const Matrix& m) const {
    if (row != m.row || col != m.col) {
        // Matrices must be of the same size for addition
        return Matrix(0, 0, 0, 0, row, col);
    }

    Matrix result(*this);
    for (int i = 0; i < row; ++i) {
        for (int j = 0; j < col; ++j) {
            result.matrix[i][j] += m.matrix[i][j];
        }
    }
    return result;
}

Matrix Matrix::Subtract(const Matrix& m) const {
    if (row != m.row || col != m.col) {
        // Matrices must be of the same size for subtraction
        return Matrix(0, 0, 0, 0, row, col);
    }

    Matrix result(*this);
    for (int i = 0; i < row; ++i) {
        for (int j = 0; j < col; ++j) {
            result.matrix[i][j] -= m.matrix[i][j];
        }
    }
    return result;
}

Matrix Matrix::Multiply(const Matrix& m) const {
    if (col != m.row) {
        // Matrices must be of compatible size for multiplication
        return Matrix(0, 0, 0, 0, row, col);
    }

    Matrix result(0, 0, 0, 0, row, m.col);
    for (int i = 0; i < row; ++i) {
        for (int j = 0; j < m.col; ++j) {
            for (int k = 0; k < col; ++k) {
                result.matrix[i][j] += matrix[i][k] * m.matrix[k][j];
            }
        }
    }
    return result;
}

int Matrix::FindkSmallest(int k) const {
    int totalElements = row * col;
    if (k <= 0 || k > totalElements) {
        // Invalid 'k' value
        return -1;
    }

    int* tempArray = new int[totalElements];
    int idx = 0;
    for (int i = 0; i < row; ++i) {
        for (int j = 0; j < col; ++j) {
            tempArray[idx++] = matrix[i][j];
        }
    }

    for (int i = 0; i < totalElements - 1; ++i) {
        for (int j = 0; j < totalElements - i - 1; ++j) {
            if (tempArray[j] > tempArray[j + 1]) {
                int temp = tempArray[j];
                tempArray[j] = tempArray[j + 1];
                tempArray[j + 1] = temp;
            }
        }
    }

    int kthSmallest = tempArray[k - 1];
    delete[] tempArray;
    return kthSmallest;
}

int Matrix::FindkLargest(int k) const {
    int totalElements = row * col;
    if (k <= 0 || k > totalElements) {
        // Invalid 'k' value
        return -1;
    }

    int* tempArray = new int[totalElements];
    int idx = 0;
    for (int i = 0; i < row; ++i) {
        for (int j = 0; j < col; ++j) {
            tempArray[idx++] = matrix[i][j];
        }
    }

    for (int i = 0; i < totalElements - 1; ++i) {
        for (int j = 0; j < totalElements - i - 1; ++j) {
            if (tempArray[j] < tempArray[j + 1]) {
                int temp = tempArray[j];
                tempArray[j] = tempArray[j + 1];
                tempArray[j + 1] = temp;
            }
        }
    }

    int kthLargest = tempArray[k - 1];
    delete[] tempArray;
    return kthLargest;
}

