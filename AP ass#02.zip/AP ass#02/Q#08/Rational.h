#ifndef UNTITLED_RATIONAL_H
#define UNTITLED_RATIONAL_H
#include <iostream>
#include <sstream>
using namespace std;

class Rational{
private:
    int Nerator;
    int Dnomiator;
public:
    Rational(int nmi = 0, int dmi = 1);
    Rational(const Rational &copy);

    Rational operator+(const Rational &x) const;
    Rational operator=(const Rational &x);
    Rational operator*(const Rational &x) const;
    Rational operator-(const Rational &x) const;
    Rational operator/(const Rational &x) const;

    Rational operator/=(const Rational &x);
    Rational operator*=(const Rational &x);
    Rational operator-=(const Rational &x);
    Rational operator+=(const Rational &x);


    bool operator>=(const Rational &other) const;
    bool operator<=(const Rational &other) const;
    bool operator>(const Rational &other) const;
    bool operator==(const Rational &other) const;
    bool operator<(const Rational &other) const;
    operator string() const;
    ~Rational();

};

Rational::Rational(int n, int d) : Nerator(n), Dnomiator(d)
{
    // Additional logic for handling zero denominator and normalization of the rational number can be added here
}

Rational::Rational(const Rational &copy) : Nerator(copy.Nerator), Dnomiator(copy.Dnomiator)
{
    // Copy constructor to initialize the Rational from an existing Rational object
}
Rational Rational::operator=(const Rational &x)
{
    if (this != &x)
    {
        Nerator = x.Nerator;
        Dnomiator = x.Dnomiator;
    }
    return *this;
}
Rational Rational::operator+(const Rational &x) const
{
    Rational result;
    result.Nerator = (Nerator * x.Dnomiator) + (x.Nerator *Dnomiator);
    result.Dnomiator = Dnomiator * x.Dnomiator;
    return result;
}

Rational Rational::operator-(const Rational &x) const
{
    Rational result;
    result.Nerator = (Nerator * x.Dnomiator) - (x.Nerator * Dnomiator);
    result.Dnomiator = Dnomiator * x.Dnomiator;
    return result;
}

Rational Rational::operator*(const Rational &x) const
{
    Rational result;
    result.Nerator = Nerator * x.Nerator;
    result.Dnomiator = Dnomiator * x.Dnomiator;
    return result;
}

Rational Rational::operator/(const Rational &x) const
{
    Rational result;
    result.Nerator = Nerator * x.Dnomiator;
    result.Dnomiator = Dnomiator * x.Nerator;
    return result;
}

Rational Rational::operator+=(const Rational &x)
{
    *this = *this + x;
    return *this;
}

Rational Rational::operator-=(const Rational &x)
{
    *this = *this - x;
    return *this;
}

Rational Rational::operator*=(const Rational &x)
{
    *this = *this * x;
    return *this;
}

Rational Rational::operator/=(const Rational &x)
{
    *this = *this / x;
    return *this;
}
bool Rational::operator==(const Rational &other) const
{
    return (Nerator * other.Dnomiator) == (other.Nerator * Dnomiator
    );
}
bool Rational::operator<(const Rational &other) const
{
    return (Nerator * other.Dnomiator) < (other.Nerator * Dnomiator);
}

bool Rational::operator>(const Rational &other) const
{
    return (Nerator * other.Dnomiator) > (other.Nerator * Dnomiator);
}



bool Rational::operator>=(const Rational &other) const
{
    return (Nerator * other.Dnomiator) >= (other.Nerator * Dnomiator);
}

bool Rational::operator<=(const Rational &other) const
{
    return (Nerator * other.Dnomiator) <= (other.Nerator * Dnomiator);
}
Rational::operator string() const
{
    stringstream ss;
    if (Dnomiator == 1)
    {
        ss << Nerator;
    }
    else
    {
        ss << Nerator << "/" << Dnomiator;
    }
    return ss.str();
}

Rational::~Rational()
{
    // Destructor implementation
}


#endif //UNTITLED_RATIONAL_H
