#include <iostream>

using namespace std;
int main()
{
    Rational rez1(2, 3);
    Rational rez2(3, 4);
    Rational result;

    result = rez1 + rez2;
    cout << "Result (rez1 + rez2): " << string(result) << endl;

    if (rez1 == rez2)
    {
        cout << "rez1 is equal to rez2." << endl;
    }
    else
    {
        cout << "rez1 is not equal to rez2." << endl;
    }

    if (rez1 < rez2)
    {
        cout << "rez1 is less than rez2." << endl;
    }
    else
    {
        cout << "rez1 is not less than rez2." << endl;
    }

    return 0;
}
