#include "Car.h"
// a setter for petrol level,
void Car::setPetrollevel(int petrollevelVal)
{
    if(petrollevelVal >= 0 && petrollevelVal <=45){
        petrollevel=petrollevelVal;
    }}
// getter for petrol level
int Car::getpetrollevel()
{
    return petrollevel;
}
Car::Car() {
    petrollevel = 0;//Defalut Constructor
}
Car::Car(int petrollevelVal){
    setPetrollevel(petrollevelVal);//parametrized constructor
}
bool Car::moveCar(int distanceKm){
    if (distanceKm <= petrollevel) {
        petrollevel -= distanceKm;
        return true; // success move
    } else {
        return false;// enough fuel
    }
}
// function that refill the car
void Car::refill(){
    petrollevel =45;
}
//check the tank is empty
bool Car::isEmpty() {
    return (petrollevel == 0);
}

