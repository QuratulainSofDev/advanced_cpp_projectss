
#ifndef UNTITLED_CAR_H
#define UNTITLED_CAR_H
struct  Car {
    int petrollevel;
    Car();
    Car(int petrollevelVal);


    //member function
    void setPetrollevel(int petrollevelVal);
    int getpetrollevel();
    bool moveCar(int distanceKm);
    void refill();
    bool isEmpty();
};

#endif //UNTITLED_CAR_H
