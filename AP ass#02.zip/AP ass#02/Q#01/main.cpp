#include "Car.h"
#include "Car.cpp"
#include <iostream>

int main() {
    // Create a car with 20 liters of petrol
    Car myCar(20);

    // Get and display the initial petrol level
    std::cout << "Initial petrol level: " << myCar.getpetrollevel() << " liters\n";

    // Move the car 10 kilometers
    if (myCar.moveCar(10)) {
        std::cout << "Car moved 10 kilometers. New petrol level:" << myCar.getpetrollevel() << " liters\n";
    } else {
        std::cout << "Car couldn't move 10 kilometers due to low petrol.\n";
    }

    // Refill the car's petrol tank
    myCar.refill();
    std::cout << "Car refilled. Petrol level: " << myCar.getpetrollevel() << " liters\n";

    // Check if the petrol tank is empty
    if (myCar.isEmpty()) {
        std::cout << "Petrol tank is empty.\n";
    } else {
        std::cout << "Petrol tank is not empty.\n";
    }

    return 0;
}
