
#ifndef UNTITLED2_ADRESS_H
#define UNTITLED2_ADRESS_H

struct address{
    char address[100];   //store adress of customer
    char city[50]; // to store city name
    char state[50]; // state name
    int zip_code;  // for postal code
};

#endif //UNTITLED2_ADRESS_H
