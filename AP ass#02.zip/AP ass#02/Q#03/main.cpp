#include "CustomerAcc.h"

int main() {
     CustomerAcc *customers[100]
     int accopen =0;

     //open sutomer account
    openCustAcc(customers, accopen, "Qurat-il-ain", "g 13 Street 9""Islamabad", "Isb", 10002, 1224467800, 4000.0);
    openCustAcc(customers, accopen, "Bisma", "g 13 Street 9""Islamabad", "Isb", 10003, 1334467800, 4000.0);

    // Display all  accounts
    DisplayCustomer(customers, accopen);

    // Update customer's address and phone number
    address newAddress = { "G-13 street 9", "Islamabad", "ISb", 60601 };
    UpdateCusAcc(customers, accopen, customers[0]->accnum, newAddress);
    UpdateCusAcc(customers, accopen, customers[1]->accnum, 924771035);

    // Display all customer accounts after updates
    DisplayCustomer(customers, accopen);

    // Deallocate memory to avoid memory leaks
    deLocateMeomry(customers, accopen);

    return 0;
}
