#include "CustomerAcc.h"
#include <iostream>
using namespace std;
//copy string data
void copystr(char *dest, const char *src){
    while (*src){
        *dest=*src;
        ++dest;
        ++src;
    }
    *dest='\0';
}
// Callculate length of the string

int strlen(const char *str){
    int len=0;
    //count chracter
    while(str[len] != '\0'){
        ++len;
    }
    return len;
}

//compare string
int comstr(const char* str1, const char *str2){
while(*str1 && *str2 &&  *str1 == *str2 ){
    ++str1;
    ++str2;
}
    return  (*str1 - *str2);
}

//open new account
void openCustAcc(CustomerAcc* customers[], int& accopen, const char*Nameval, const char* addval, const char* cityval, const char*stateval, int zipcodeval, long long phnoval,float balanceVal){
if (accopen<100){
customers[accopen]= new CustomerAcc;
//copy  the string
  copystr(customers[accopen] -> name, Nameval);
  copystr(customers[accopen] -> address.address, addval);
  copystr(customers[accopen] -> address.city, cityval);
  copystr(customers[accopen] -> address.state, stateval);
  customers[accopen] -> address.zip_code=zipcodeval;
  customers[accopen] -> address.phno=phnoval;
  customers[accopen] -> address.balance=balanceVal;

  //generate acc num based on current acc
  int accnum = accopen +1;
  customers[accopen]->accnum[0]='P';
  customers[accopen]->accnum[1]='K';
  customers[accopen]->accnum[2]='0';+ (accnum/100)%10;
  customers[accopen]->accnum[3]='0';+ (accnum/100)%10;
  customers[accopen]->accnum[4]='0';+ (accnum/100)%10;
  customers[accopen]->accnum[5]='\0';
  accopen++;
}else{
    cout<<"maximum Account reached, cannot open new account "<<endl;
}}
//Searching user account number
int SearchCus(CustomerAcc* customers[], int accopen, const char* accnum){
    for(int i=0; i< accopen; ++i){
        //compare the acc num in record
        if(comstr(customers[i] -> accnum, accnum)==0){
            return i;
        }
    }
    return  -1;// return -1 if the account number is not found
}

//function to update adress
bool UpdateCusAcc(CustomerAcc* customers[], int& accopen,const char*accnumval, long long phoneval) {
    int index = SearchCus(customers, accopen, accnumval);
    if (index != -1) {
        //new adress detail
        copystr(customers[index]->address.address, addval.address);
        copystr(customers[index]->address.city, addval.city);
        copystr(customers[index]->address.state, addval.state);
        copystr(customers[index]->address.zip_code = addval.zip_code);
        return true;
    }
    return false;
}


//update customer phone number
    bool UpdateCusAcc(CustomerAcc* customers[], int accopen,const char*accnumval, long long  phoneval);
    {
        int index =searchCus(customers, accopen,accnumval);
        if(index != -1)
        {
            customers[index]->phno=phoneval;
            return true;
        }
        return false;
    }
//update customer balance
    bool UpdateCusAcc(CustomerAcc* customers[], int accopen,const char*accnumval, float balanceVal);
{
        int index =searchCus(customers, accopen,accnumval);
         if(index != -1)
         {
             customers[index]->balance=balanceVal;
                return true;
         }
            return false;
    }
//Display customer accounts
void DisplayCustomer(CustomerAcc* customers[], int accOpen);{
       cout<<"Display all customer accounts"<<endl;
       for(int i=0; i<accopen; ++i)    {
           //Display all customer accounts
            cout<<"Customer "<<i +1 <<":"<<endl;
            cout<<"Name:"<<customers[i]->name<<endl;
            cout<<"Acoount Number:"<<customers[i]->accnum<<endl;
            cout<<"Phone Number:"<<customers[i]->phno<<endl;
            cout<<"Balance :"<<customers[i]->balnce<<endl;
       }
}

// function  to dealocate memory
void deLocateMeomry(CustomerAcc* customers[], int accOpen); {
    for (int i = 0; i < accopen; ++i) {
        delete customers[i]; // Free memory for each customer account
    }
}
