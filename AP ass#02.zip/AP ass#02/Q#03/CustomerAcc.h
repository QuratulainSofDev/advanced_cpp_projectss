
#ifndef UNTITLED2_CUSTOMERACC_H
#define UNTITLED2_CUSTOMERACC_H
#include "adress.h"

struct CustomerAcc{
    char name[20];  // name of customer
    Address address; // detailed address
    long long phno;// phone number
    float balance;  //customer's account balance
    char accnum[6]; //customer's account number
};
// Opreations on cutomer account
void openCustAcc(CustomerAcc* customers[], int& accopen, const char*Nameval, const char* addval, const char* cityval, const char*stateval, int zipcodeval, long long phnoval,float balanceVal);
int SearchCus(CustomerAcc* customers[], int& accopen,const char*accnumval);
bool UpdateCusAcc(CustomerAcc* customers[], int& accopen,const char*accnumval, const Address& addressVal);
bool UpdateCusAcc(CustomerAcc* customers[], int& accopen,const char*accnumval, long long  phoneval);
bool UpdateCusAcc(CustomerAcc* customers[], int& accopen,const char*accnumval, float balanceVal);
void DisplayCustomer(CustomerAcc* customers[], int accOpen);
void  deLocateMeomry(CustomerAcc* customers[], int accOpen);

#endif //UNTITLED2_CUSTOMERACC_H
