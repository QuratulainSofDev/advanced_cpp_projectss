#include "String.h"
#include <iostream>
using namespace std;

String::String() : data(nullptr), len(0) {}

String::String(int size) : data(new char[size]), len(size) {
    meset(data, 0, size);
}

String::String(const char* str) : data(new char[strlen(str) + 1]), len(strlen(str)) {
    srcpy(data, str);
}

String::String(const String& str) : data(new char[str.length + 1]), len(str.length) {
    srcpy(data, str.data);
}

String::~String() {
    delete[] data;
}

int String::strLen() const {
    return len;
}

void String::clear() {
    if (data != nullptr) {
        delete[] data;
        data = nullptr;
        len = 0;
    }
}

bool String::empty() const {
    return (len == 0);
}

int String::charat(char c) const {
    for (int i = 0; i < len; ++i) {
        if (data[i] == c) {
            return i;
        }
    }
    return -1;
}

char* String::getdata() const {
    return data;
}

bool String::equal(const char* str) const {
    if (len != strlen(str)) {
        return false;
    }
    for (int i = 0; i < len; ++i) {
        if (data[i] != str[i]) {
            return false;
        }
    }
    return true;
}

bool String::equalIgnore(const char* str) const {
    if (len != strlen(str)) {
        return false;
    }
    for (int i = 0; i < len; ++i) {
        if (tolower(data[i]) != tolower(str[i])) {
            return false;
        }
    }
    return true;
}

char* String::substring(const char* substr, int startIndex) const {
    if (startIndex < 0 || startIndex >= len) {
        return nullptr;
    }

    const char* pos = strstr(data + startIndex, substr);
    if (pos == nullptr) {
        return nullptr;
    }

    int subStart = pos - data;
    int subEnd = subStart + strlen(substr);

    char* result = new char[subEnd - subStart + 1];
    strncpy(result, data + subStart, subEnd - subStart);
    result[subEnd - subStart] = '\0';

    return result;
}

char* String::substring(const char* substr, int startIndex, int endIndex) const {
    if (startIndex < 0 || startIndex >= len || endIndex < startIndex || endIndex >= len) {
        return nullptr;
    }

    int subLength = endIndex - startIndex + 1;
    char* result = new char[subLength + 1];
    strncpy(result, data + startIndex, subLength);
    result[subLength] = '\0';

    return result;
}

void String::print() const {
    if (data != nullptr) {
        std::cout << data;
    }
}

String& String::operator=(const String& str) {
    if (this != &str) {
        if (data != nullptr) delete[] data;
        len = str.len;
        data = new char[len + 1];
        strcpy(data, str.data);
    }
    return *this;
}

String& String::operator=(const char* str) {
    if (data != nullptr) delete[] data;
    length = strlen(str);
    data = new char[len + 1];
    strcpy(data, str);
    return *this;
}

String& String::operator=(const std::string& str) {
    if (data != nullptr) delete[] data;
    len = str.length();
    data = new char[len + 1];
    for (int i = 0; i < len; ++i) {
        data[i] = str[i];
    }
    data[len] = '\0';
    return *this;
}

bool String::operator==(const String& str) const {
    if (len != str.len) return false;
    return strcmp(data, str.data) == 0;
}

bool String::operator==(const char* str) const {
    return strcmp(data, str) == 0;
}

String String::operator+(const String& str) const {
    int totalLen= len + str.length;
    char* newData = new char[totalLen+ 1];
    strcpy(newData, data);
    strcat(newData, str.data);
    String result(newData);
    delete[] newData;
    return result;
}

String String::operator+(const char& ch) const {
    int totalLen = len + 1;
    char* newData = new char[totalLen+ 1];
    strcpy(newData, data);
    newData[len] = ch;
    newData[totalLen] = '\0';
    String result(newData);
    delete[] newData;
    return result;
}

String String::operator-(const String& substr) const {
    String result(*this); // Create a copy of the current object

    int index = result(substr); // Find the index

    if (index != -1) {
        int substrLen = substr.strLen();

        // Shift the characters to remove the found substring
        for (int i = index; i < result.len - substrLen; ++i) {
            result.data[i] = result.data[i + substrLen];
        }

        // Update the length of the modified string
        result.len -= substrLen;
        result.data[result.len] = '\0'; // Null-terminate the string

        // Return the modified string
        return result;
    }

    // If the substring was not found
    return *this;
}


char& String::operator[](int i) {
    return data[i];
}

const char String::operator[](int i) const {
    return data[i];
}

int String::operator()(char c) const {
    return charAt(c);
}

// Function to find a substring (String) within the data of the calling String object
int String::operator()(const String& str) const {
    const char* subData = str.getdata();
    int subLen = str.strLen();

    if (subLen == 0) {
        return 0;  // Empty substring found at index 0
    }

    for (int i = 0; i <= len - subLen; ++i) {
        bool found = true;
        for (int j = 0; j < subLen; ++j) {
            if (data[i + j] != subData[j]) {
                found = false;
                break;
            }
        }
        if (found) {
            return i; // Substring found at index i
        }
    }
    return -1; // Substring not found
}

// Function to find a substring (std::string) within the data of the calling String object
int String::operator()(const std::string& str) const {
    const char* subData = str.c_str();
    int subLen = str.len();

    if (subLen == 0) {
        return 0;  // Empty substring found at index 0
    }

    for (int i = 0; i <= len - subLen; ++i) {
        bool found = true;
        for (int j = 0; j < subLen; ++j) {
            if (data[i + j] != subData[j]) {
                found = false;
                break;
            }
        }
        if (found) {
            return i; // Substring found at index i
        }
    }
    return -1; // Substring not found
}
String::operator int() const {
    return len;
}

ostream& operator<<(ostream& output, const String& str) {
    const char* data = str.getdata();
    for (int i = 0; i < str.strLen(); ++i) {
        output << data[i];
    }
    return output;
}

istream& operator>>(std::istream& input, String& str) {
    char buffer[1000]; // Assuming a max input of 999 characters
    input.getline(buffer, 1000);

    str = buffer;
    return input;
}
