#include <iostream>
#include "Sequence.h"
#include "Sequence.cpp"

int main() {
    // test the sequence
    Sequence sq1;//default constructor
    Sequence sq2(5,4,3,2,1,0);//parameter cnstructor
    Sequence sq3(sq2);//copy constructor

    //getter
    std::cout<<"length of sequnce2:"<<sq2.getlen()<<std::endl;
    std::cout<<"length of sequnce2: ";
    int* seq2array =sq2.getseq();
    for (int i = 0; i <sq2.getlen() ; i++) {
        std::cout << seq2array[i] <<" ";
    }
    std::cout<<std::endl;
    //test sort
    sq2.sort(5);
    std::cout<<"sorted sequence of seq2: ";
    seq2array = sq2.getseq();
    for(int i=0; i<sq2.getlen(); i++){
        std::cout<<seq2array[i]<<" ";
    }
    std::cout<<std::endl;
    //remove duplicate
    int count = sq2.remdup();
    std::cout<<"unique  element in sequnce2 "<<count<<std::endl;
    std::cout<<" sequnce after removing duplicate: ";
    seq2array =sq2.getseq();
    for (int i = 0; i <count ; i++) {
        std::cout<<seq2array[i]<<" ";
    }
    std::cout<<std::endl;


    //Test Rotate
    sq2.rotate(2);
    std::cout<<"sequence after rotating by two steps";
    seq2array=sq2.getseq();
    for (int i = 0; i <count ; ++i) {
        std::cout<<seq2array[i]<<" ";
    }
    std::cout<<std::endl;
    return 0;

}
