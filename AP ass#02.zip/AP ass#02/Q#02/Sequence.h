#ifndef SEQUENCE_H
#define SEQUENCE_H

class Sequence {
private:
    int length;
    int *pseq;

public:
    Sequence();
    Sequence(int lengthVal, int n1 = 0, int n2 = 0, int n3 = 0, int n4 = 0, int n5 = 0, int n6 = 0, int n7 = 0, int n8 = 0, int n9 = 0, int n10 = 0);
    Sequence(const Sequence &s);
    ~Sequence();

    int getlen() const;
    int* getseq() const;
    void sort(int n);
    int remdup();
    void rotate(int steps);
};

#endif
