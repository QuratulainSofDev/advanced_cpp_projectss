#include "Sequence.h"

Sequence::Sequence() {
    length = 10;
    pseq = new int[length];
    for (int i = 0; i < length; i++) {
        pseq[i] = 0;
    }
}

Sequence::Sequence(int lengthVal, int n1, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10) {
    length = lengthVal;
    pseq = new int[length];
    int args[] = {n1, n2, n3, n4, n5, n6, n7, n8, n9, n10};
    for (int i = 0; i < length; i++) {
        pseq[i] = args[i];
    }
}

Sequence::Sequence(const Sequence &s) {
    length = s.length;
    pseq = new int[length];
    for (int i = 0; i < length; i++) {
        pseq[i] = s.pseq[i];
    }
}

Sequence::~Sequence() {
    delete[] pseq;
}

int Sequence::getlen() const {
    return length;
}

int* Sequence::getseq() const {
    return pseq;
}

void Sequence::sort(int n) {
    // Implement sorting algorithm (e.g., quicksort, merge sort, etc.) here
}

int Sequence::remdup() {
    // Implement duplicate removal logic here
}

void Sequence::rotate(int steps) {
    // Implement rotation logic here
}
