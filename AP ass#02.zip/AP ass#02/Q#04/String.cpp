#include "String.h"
#include <iostream>
using namespace std;

class String {
private:
char* data; // hold a chracter array
int length;// current length of the string
public:
    String() : length(0), data(new char[1]) {
        data[0] = '\0';
    }
    String(int size) : length(size), data(new char[length +1]){
        for (int i = 0; i < length; ++i) {
            data[i] =' ';
        }
        data[length] ='\0';
    }
    String(const char *str){
        length =0;
        while(str[length] != '\0'){
            ++length;
        }
    data = new char[length +1];
     for(int i=0; i<length; ++i ){
         data[i] =str[i];
     }
     data[length] ='\0';
    }

    String(const String &str){ // copy constructor
        length = str.length;
        data = new char[length+1];
        for(int i = 0; i<length; ++i){
        data[i] = str.data[i];
        }
        data[length] ='\0';
    }
    ~String() {
        delete[] data;
    }

    int strlen() const { // Returns the length of the string
        return length;
    }

    void clear() { // Clears the data in the string
        delete[] data;
        length = 0;
        data = new char[1];
        data[0] = '\0';
    }

    bool empty() const { // Checks if data within the string or not
        return length == 0;
    }

    int charRt(char c) const { // Returns the first index at which the character occurs in the string
        for (int i = 0; i < length; ++i) {
            if (data[i] == c) {
                return i;
            }
        }
        return -1;
    }
    char* getdata() const { // Getter to get the actual string
        return data;
    }

    bool equals(const char* str) const { // DATA calling string object is equal to str
        int len = 0;
        while (str[len] != '\0') {
            ++len;
        }

        if (len != length) {
            return false;
        }

        for (int i = 0; i < length; ++i) {
            if (data[i] != str[i]) {
                return false;
            }
        }

        return true;
    }

    bool equalsisignore(const char* str) const { // Compares the calling string object data with the data in str without considering the case
        int len = 0;
        while (str[len] != '\0') {
            ++len;
        }

        if (len != length) {
            return false;
        }

        for (int i = 0; i < length; ++i) {
            if (data[i] != str[i] && data[i] != str[i] - 32 && data[i] != str[i] + 32) {
                return false;
            }
        }

        char* substring(const char* substr, int startIndex ) const; { // Searches for substr in data within the calling String object starting from startIndex
            int sublen = 0;
            while (substr[sublen] != '\0') {
                ++sublen;
            }

            int subIndex = -1;
            for (int i = startIndex; i < length; ++i) {
                int j = 0;
                while (j < sublen && data[i + j] == substr[j]) {
                    ++j;
                }

                if (j == sublen) {
                    subIndex = i;
                    break;
                }
            }
            if (subIndex != -1) {
                char* result = new char[length - subIndex + 1];
                for (int i = 0; i < length - subIndex; ++i) {
                    result[i] = data[subIndex + i];
                }
                result[length - subIndex] = '\0';
                return result;
            }

            return nullptr;
        }
        char* substring(const char* substr, int startIndex, int endIndex) const { // Searches for substr between startIndex and endIndex
            int subLen = 0;
            while (substr[subLen] != '\0') {
                ++subLen;
            }

            int subIndex = -1;
            for (int i = startIndex; i < endIndex - sublen + 1; ++i) {
                int j = 0;
                while (j < sublen && data[i + j] == substr[j]) {
                    ++j;
                }

                if (j == sublen) {
                    subIndex = i;
                    break;
                }
            }

        return true;
    }
        if (subIndex != -1) {
            char* result = new char[endIndex - (startIndex + (subIndex - startIndex)) + 1];
            for (int i = 0; i < endIndex - (startIndex + (subIndex - startIndex)); ++i) {
                result[i] = data[startIndex + (subIndex - startIndex) + i];
            }
            result[endIndex - (startIndex + (subIndex - startIndex))] = '\0';
            return result;
        }

        return nullptr;
    }

    void show() const { // Outputs the contents of the character array within the object
        if (length == 0) {
            cout << "NULL" << endl;
        } else {
            for (int i = 0; i < length; ++i) {
                cout << data[i];
            }
            cout << endl;
        }
    }
};
