

#ifndef UNTITLED3_STRING_H
#define UNTITLED3_STRING_H
class String{
private:
    char* data; // hold a chracter array
    int length;// current length of the string

public:
    String(); // defalut constructor
    String(int size);// alternate constructor
    String(const char* str);//alternate constructor
    String(const String &str);// copy constructor
    ~String();//deconstructor

    int strlen() const;//return length
    void clear();//clear data
    bool empty() const;//check data within the string
    int charRt(char c) const;//return first index
    char* getdata() const;//getter to get actual vale
    bool equals(const char* str) const;
    bool equalsisignore(const char *str)const;//compare if data in calling string
    char* substring(const char* substr, int startIndex )const;//
    char*  substring(const char* substr, int startIndex , int endIndex)const;
    void show() const;




};

#endif //UNTITLED3_STRING_H
